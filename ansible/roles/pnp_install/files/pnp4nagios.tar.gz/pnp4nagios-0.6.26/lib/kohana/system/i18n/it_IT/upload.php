<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'not_writable'       => 'La cartella di destinazione, %s, non sembra avere i permessi in scrittura.',
);

<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'invalid_subject'  => 'Fallito il tentativo di aggiungere il soggetto <tt>%s</tt> a <tt>%s</tt>. I soggetti devono estendere la classe <tt>Event_Subject</tt>.',
	'invalid_observer' => 'Fallito il tentativo di aggiungere l\'observer <tt>%s</tt> a <tt>%s</tt>. Gli observer devono estendere la classe <tt>Event_Observer</tt>.',
);

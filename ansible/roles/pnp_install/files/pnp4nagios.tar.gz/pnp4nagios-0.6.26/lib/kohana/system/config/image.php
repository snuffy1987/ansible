<?php defined('SYSPATH') OR die('No direct access allowed.');
/**
 * @package  Image
 *
 * Driver name. Default: GD
 */
$config['driver'] = 'GD';

/**
 * Driver parameters:
 * ImageMagick - set the "directory" parameter to your ImageMagick installation directory
 */
$config['params'] = array();
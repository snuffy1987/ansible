<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'undefined_group' => 'Le groupe %s n\'est pas défini dans votre configuration de la pagination.', 
	'page'     => 'page',
	'pages'    => 'pages',
	'item'     => 'résultat',
	'items'    => 'résultats',
	'of'       => 'sur',
	'first'    => 'premier',
	'last'     => 'dernier',
	'previous' => 'précédent',
	'next'     => 'suivant',
);

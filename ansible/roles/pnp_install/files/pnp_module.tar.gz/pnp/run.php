<?php

$this->provideHook('grapher');
